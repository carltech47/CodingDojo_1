console.log("page loaded...");

function playVideo(vid) {
    console.log(vid);
    vid.play();
}

function pauseVideo(vid) {
    console.log(vid);
    vid.pause();
}